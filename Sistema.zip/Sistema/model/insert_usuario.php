<?php

include "../php/conexion.php";
session_start();

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Obtén los datos del formulario
    $nombre = $_POST["nombre"];
    $identidad_usuario = $_POST["identidad_usuario"];
    $direccion = $_POST["direccion"];
    $telefono = $_POST["telefono"];
    $correo = $_POST["correo"];
    $usuario = $_POST["usuario"];
    $pass = $_POST["pass"];
    //$creado_por = $_SESSION["usuario"]["usuario"]; // Ajusta según tu estructura de sesión

    $sql = "INSERT INTO usuarios (nombre, identidad_usuario, direccion, telefono, correo, usuario, pass)
  VALUES ('$nombre_usuario' & '$apellido_usuario', '$identidad_usuario', '$direccion_usuario', '$tele_usuario', '$correo_usuario', '$apodo_usuario', '$contra_usuario', '$registro_fecha')";




    if (mysqli_query($conexion,$sql)) {
        header("Location: ../Login.php?success=true");
        exit();
    } else {
        if (mysqli_errno($conexion) == 1062) {
            echo '<div class="alert alert-danger text-center">Error ID Ya Existente</div>';
        } else {
            echo '<div class="alert alert-warning text-center">Algunos Campos Estan Vacios</div>';
        }else{
             echo "Nuevo registro insertado correctamente";

        }

    }

    mysqli_close($conexion);
}
?>

//php
include "../php/conexion.php";


// Datos a insertar
$idusuario = 1; // Aquí colocarías el ID del usuario
$nombre_usuario = "Juan";
$contra_usuario = "contraseña";
$correo_usuario = "juan@example.com";
$tele_usuario = "123456789";
$direccion_usuario = "Calle 123";
$Habilitar_desahabilitar = "Enabled";
$idestado = 1; // Aquí colocarías el ID del estado
$apellido_usuario = "Pérez";
$identidad_usuario = "12345678";
$apodo_usuario = "Juancito";
$registro_fecha = date("Y-m-d H:i:s");

// Query de inserción
$sql = "INSERT INTO usuarios (idusuario, nombre_usuario, contra_usuario, correo_usuario, tele_usuario, direccion_usuario, Habilitar_desahabilitar, idestado, apellido_usuario, identidad_usuario, apodo_usuario, registro_fecha)
VALUES ('$idusuario', '$nombre_usuario', '$contra_usuario', '$correo_usuario', '$tele_usuario', '$direccion_usuario', '$Habilitar_desahabilitar', '$idestado', '$apellido_usuario', '$identidad_usuario', '$apodo_usuario', '$registro_fecha')";

if ($conn->query($sql) === TRUE) {
  echo "Nuevo registro insertado correctamente";
} else {
  echo "Error: " . $sql . "<br>" . $conn->error;
}

// Cerrar conexión (si es que no la cierras dentro de `conexion.php`)
$conn->close();
?>//
